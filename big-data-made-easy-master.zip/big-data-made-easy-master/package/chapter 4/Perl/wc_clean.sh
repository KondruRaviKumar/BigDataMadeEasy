#!/bin/bash

# Clean the hadoop perl run data directory

hadoop dfs -rmr /user/hadoop/perl/results_wc

