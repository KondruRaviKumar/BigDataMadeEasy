#!/bin/bash

# test the mapper 

echo "one one one two three" | ./mapper.pl | ./reducer.pl

