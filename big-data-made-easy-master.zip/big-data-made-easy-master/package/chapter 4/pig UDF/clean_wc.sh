#!/bin/bash

# remove the pig script results directory

hadoop dfs -rmr /user/hadoop/pig/wc_result1
