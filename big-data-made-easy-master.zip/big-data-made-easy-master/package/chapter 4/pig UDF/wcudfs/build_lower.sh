
javac -classpath $PIG_HOME/pig-0.12.1.jar \
   -Xlint:deprecation Lower.java
