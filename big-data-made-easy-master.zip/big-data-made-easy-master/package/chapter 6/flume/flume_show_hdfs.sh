#!/bin/bash

hdfs dfs -ls /flume/messages
