#!/bin/bash

hdfs dfs -rm -r /flume/messages
